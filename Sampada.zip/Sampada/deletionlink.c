#include<stdio.h>
#include<stdlib.h>
void main()
{
    struct node*

}
