#include<stdio.h>
int main()
{
    short a;
    short e;
    int b;
    float c;
    printf("%hu",-5);

}
