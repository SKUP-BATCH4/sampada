#include<stdio.h>
void main()
{
    char k='@',a='#';
    int i;
    i=(k<=a)?printf("%c\n",k):printf("%c\n",a);
}
