#include<stdio.h>
int main()
{
    char k='o' ;
    ++k;
    printf("%d",k);
}
